/******************************************************************************
 * @file     main.c
 * @brief    Application example triggering fault exceptions
 * @version  V1.00
 * @date     10. July 2017
 ******************************************************************************/
/*
 * Copyright (c) 2017 ARM Limited. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "RTE_Components.h"             // Component selection
#include CMSIS_device_header            // Include device header file from
                                        // RTE_Components.h
#include "project_configuration.h"      // Header file for test case configuration

__asm void undef(void);                 // Assembly function for the undefined
                                        // instruction test

volatile int i, j = 0;                  // Variables for the division-by-zero


// Function written in assembly language, calling an invalid instruction
__asm void undef(void)
{
    DCI  0xF123                         // DCI is not an ARM assmebly instruction
    DCI  0x4567
    BX   LR
}


// main function containing all the tests
int main (void) {
  SCB->CCR = 0x210;                     // enable div-by-zero trap in processor core
 
#if TESTCASE == 0
	undef();                              // Call undef() function that contains an
	                                      // invalid instruction
 
#elif TESTCASE == 1
	typedef void (*t_funcPtr)(void);
  t_funcPtr MyFunc = (t_funcPtr)(0x0001000 | 0x0);  // INVSTATE because jumping
	                                                  // to valid address but
	                                                  // thumb bit not set
	MyFunc();
 
#elif TESTCASE == 2
  i =i/j;                               // i and j are 0 initialized -> Div/0
#endif
 
  for (;;) {}
}
